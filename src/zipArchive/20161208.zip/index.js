
var Alexa = require('alexa-sdk');

//var CallAPIs = require("./CallAPIs");


exports.handler = function(event, context, callback){

    var alexa = Alexa.handler(event, context);
    // alexa.appId = "amzn1.echo-sdk-ams.app.8c97fc78-342a-4e4f-823b-e2f91e7f3474";
    //alexa.dynamoDBTableName = 'StationStore';  // Auto created.  Be sure to add Dynamo to your lambda execution role

    alexa.registerHandlers(handlers);
    alexa.execute();

};

var handlers = {
    'LaunchRequest': function () {
        var say = 'Welcome to City Bike.';
        this.emit(':ask', say, 'try again');
    },

    'SetStationIntent': function() {

        var stationName = this.event.request.intent.slots.stationName.value;
        var say = "";

        if (stationName == null) { // no slot
            say = 'I don\'t seem to have your station name or number. What is it?';
        } else {
            // create and store session attributes
            this.attributes['stationName'] = stationName;
            say = 'Your station name is ' + stationName + '!';
        }

        this.emit(':ask', say, 'try again');
    },

    'StatusRequestIntent': function() {

        stationName = this.attributes['stationName'];
        var say = "";

        if (stationName == null) { // no slot
            this.emit('SetStationIntent');

        } else {
            // create and store session attributes
            say = 'There are 39 bikes at '+ stationName;
        }

        this.emit(':ask', say, 'try again');
    },

    'AMAZON.HelpIntent': function () {
        this.emit(':ask', 'Say manage my station or how many bikes are there.', 'try again');
    },

    'AMAZON.StopIntent': function () {
        var say = '';
        say = 'Goodbye, thanks for using City Bike';

        this.emit(':tell', say );
    }
}
// end of handlers

// ---------------------------------------------------  User Defined Functions ---------------
