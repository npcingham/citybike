
var Alexa = require('alexa-sdk');

//var CallAPIs = require("./CallAPIs");


exports.handler = function(event, context, callback){

    var alexa = Alexa.handler(event, context);
    // alexa.appId = "amzn1.echo-sdk-ams.app.8c97fc78-342a-4e4f-823b-e2f91e7f3474";
    //alexa.dynamoDBTableName = 'StationStore';  // Auto created.  Be sure to add Dynamo to your lambda execution role

    alexa.registerHandlers(handlers);
    alexa.execute();

};

var handlers = {
    'LaunchRequest': function () {
        var say = ""; 
        say = 'Welcome to City Bike.';
        // this.emit('StatusRequestIntent');
        this.emit('StatusRequestIntent');
        
    },

    'SetStationIntent': function() {

        var stationName = this.event.request.intent.slots.stationName.value;
        var say = "";

        if (stationName == null) { // no slot
            say = 'I don\'t seem to have your station name or number. What is it?';
        } else {
            // create and store session attributes
            this.attributes['stationName'] = stationName;
            say = 'Your station name is ' + stationName + '. Do you want to see how many bikes there are?';
        }
        this.emit(':ask', say, 'try again');
    },
    'AMAZON.YesIntent': function() {

        this.emit('StatusRequestIntent');
    },
    'AMAZON.NoIntent': function() {

        this.emit(':tell', 'Ok, see you next time!');
    },

    'StatusRequestIntent': function() {

        var stationName = this.attributes['stationName'];
        var say = "";

        if (stationName == null) { // no slot
            this.emit('SetStationIntent');

        } else {
            // create and store session attributes
            say = 'There are 39 bikes at '+ stationName;
        }

        this.emit(':ask', say, 'try again');
    },

    'AMAZON.HelpIntent': function () {
        this.emit(':ask', 'Say manage my station or how many bikes are there.', 'try again');
    },

    'AMAZON.StopIntent': function () {
        this.emit(':tell','Goodbye, thanks for using City Bike');
    },
}
// end of handlers

// ---------------------------------------------------  User Defined Functions ---------------
